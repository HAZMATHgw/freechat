-- ============================================================
--  2-3 갤러리 · Supabase 초기 설정
--  대시보드 > SQL Editor 에 전부 붙여넣고 Run 한 번이면 끝난다.
-- ============================================================

-- 1) 게시글 테이블 ------------------------------------------------
create table if not exists public.posts (
  id          uuid primary key default gen_random_uuid(),
  title       text not null check (char_length(title) between 1 and 200),
  body        text not null default '',
  attachments jsonb not null default '[]'::jsonb,   -- [{name,size,type,path,url}, ...]
  created_at  timestamptz not null default now()
);

create index if not exists posts_created_at_idx
  on public.posts (created_at desc);

alter table public.posts enable row level security;

-- 로그인 없이 쓰는 반 게시판이므로 anon 키에 읽기/쓰기/삭제를 모두 연다.
drop policy if exists "누구나 읽기"   on public.posts;
drop policy if exists "누구나 쓰기"   on public.posts;
drop policy if exists "누구나 삭제"   on public.posts;

create policy "누구나 읽기" on public.posts
  for select using (true);

create policy "누구나 쓰기" on public.posts
  for insert with check (true);

create policy "누구나 삭제" on public.posts
  for delete using (true);

-- 2) 첨부파일 버킷 ------------------------------------------------
-- file_size_limit: 파일 1개당 최대 용량(바이트).
--   Free 요금제는 52428800(50MB)이 상한이다.
--   Pro 이상이면 아래 숫자와 대시보드의 Global file size limit을 같이 올리면 된다.
insert into storage.buckets (id, name, public, file_size_limit)
values ('attachments', 'attachments', true, 52428800)
on conflict (id) do update
  set public = true,
      file_size_limit = excluded.file_size_limit;

drop policy if exists "첨부파일 공개 읽기" on storage.objects;
drop policy if exists "첨부파일 업로드"   on storage.objects;
drop policy if exists "첨부파일 삭제"     on storage.objects;

create policy "첨부파일 공개 읽기" on storage.objects
  for select using (bucket_id = 'attachments');

create policy "첨부파일 업로드" on storage.objects
  for insert with check (bucket_id = 'attachments');

create policy "첨부파일 삭제" on storage.objects
  for delete using (bucket_id = 'attachments');

-- 3) 실시간 반영 (다른 사람이 올린 글이 새로고침 없이 뜬다) --------
-- 이미 등록돼 있으면 그냥 넘어간다.
do $$
begin
  alter publication supabase_realtime add table public.posts;
exception
  when duplicate_object then null;
  when others then null;
end $$;
