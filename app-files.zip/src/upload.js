import * as tus from 'tus-js-client'
import { supabase, SUPABASE_URL, SUPABASE_ANON_KEY, BUCKET } from './supabase'

/** 6MB를 넘으면 재개 가능한(resumable) 업로드가 훨씬 안정적이다. */
const RESUMABLE_THRESHOLD = 6 * 1024 * 1024

/** Storage 객체 키에 쓸 수 없는 문자를 정리한다. */
function safeName(name) {
  const cleaned = name
    .normalize('NFC')
    .replace(/[^\p{L}\p{N}._-]+/gu, '_')
    .slice(-120)
  return cleaned || 'file'
}

export function makeObjectPath(file) {
  const stamp = Date.now().toString(36)
  const rand = Math.random().toString(36).slice(2, 8)
  return `posts/${stamp}-${rand}-${safeName(file.name)}`
}

/** 6MB 이하: 한 번에 올린다. */
async function standardUpload(file, path, onProgress) {
  onProgress(0)
  const { error } = await supabase.storage.from(BUCKET).upload(path, file, {
    cacheControl: '3600',
    upsert: false,
    contentType: file.type || 'application/octet-stream',
  })
  if (error) throw error
  onProgress(1)
}

/** 6MB 초과: TUS 프로토콜로 6MB씩 잘라서 올리고, 끊기면 이어서 올린다. */
function resumableUpload(file, path, onProgress) {
  return new Promise((resolve, reject) => {
    const upload = new tus.Upload(file, {
      endpoint: `${SUPABASE_URL}/storage/v1/upload/resumable`,
      retryDelays: [0, 3000, 5000, 10000, 20000],
      headers: {
        authorization: `Bearer ${SUPABASE_ANON_KEY}`,
        'x-upsert': 'false',
      },
      uploadDataDuringCreation: true,
      removeFingerprintOnSuccess: true,
      // Supabase는 정확히 6MB 청크만 허용한다. 바꾸지 말 것.
      chunkSize: 6 * 1024 * 1024,
      metadata: {
        bucketName: BUCKET,
        objectName: path,
        contentType: file.type || 'application/octet-stream',
        cacheControl: '3600',
      },
      onError: (error) => reject(error),
      onProgress: (sent, total) => onProgress(total ? sent / total : 0),
      onSuccess: () => resolve(),
    })

    upload.findPreviousUploads().then((previous) => {
      if (previous.length) upload.resumeFromPreviousUpload(previous[0])
      upload.start()
    })
  })
}

/**
 * 파일 하나를 올리고, 게시글에 저장할 메타데이터를 돌려준다.
 * onProgress는 0~1 사이의 진행률을 받는다.
 */
export async function uploadFile(file, onProgress = () => {}) {
  const path = makeObjectPath(file)

  if (file.size > RESUMABLE_THRESHOLD) {
    await resumableUpload(file, path, onProgress)
  } else {
    await standardUpload(file, path, onProgress)
  }

  const { data } = supabase.storage.from(BUCKET).getPublicUrl(path)
  return {
    name: file.name,
    size: file.size,
    type: file.type || 'application/octet-stream',
    path,
    url: data.publicUrl,
  }
}

export function formatBytes(bytes) {
  if (!bytes && bytes !== 0) return ''
  const units = ['B', 'KB', 'MB', 'GB']
  let value = bytes
  let i = 0
  while (value >= 1024 && i < units.length - 1) {
    value /= 1024
    i += 1
  }
  return `${value.toFixed(value >= 10 || i === 0 ? 0 : 1)}${units[i]}`
}
