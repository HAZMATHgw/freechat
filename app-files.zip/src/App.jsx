import { useCallback, useEffect, useRef, useState } from 'react'
import { supabase, BUCKET, MAX_FILE_SIZE, IS_CONFIGURED } from './supabase'
import { uploadFile, formatBytes } from './upload'
import mascotLeft from './assets/mascot-left.webp'
import mascotRight from './assets/mascot-right.webp'

const MAX_MB = Math.round(MAX_FILE_SIZE / 1024 / 1024)

function Banner() {
  return (
    <header className="banner">
      <img className="mascot mascot-left" src={mascotLeft} alt="" aria-hidden="true" />
      <h1 className="banner-title">2-3 갤러리</h1>
      <img className="mascot mascot-right" src={mascotRight} alt="" aria-hidden="true" />
    </header>
  )
}

function Composer({ onPosted }) {
  const [title, setTitle] = useState('')
  const [body, setBody] = useState('')
  const [files, setFiles] = useState([])
  const [progress, setProgress] = useState(null) // { name, ratio, index, total }
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const inputRef = useRef(null)

  const addFiles = (list) => {
    const picked = Array.from(list)
    const tooBig = picked.filter((f) => f.size > MAX_FILE_SIZE)
    if (tooBig.length) {
      setError(`${tooBig[0].name} 은(는) ${MAX_MB}MB를 넘어 올릴 수 없습니다.`)
    } else {
      setError('')
    }
    const ok = picked.filter((f) => f.size <= MAX_FILE_SIZE)
    setFiles((prev) => [...prev, ...ok])
  }

  const removeFile = (index) => setFiles((prev) => prev.filter((_, i) => i !== index))

  const submit = async () => {
    if (!IS_CONFIGURED) {
      setError('config.js에 Supabase 주소와 키를 먼저 넣어 주세요.')
      return
    }
    if (!title.trim()) {
      setError('제목을 입력하세요.')
      return
    }
    setBusy(true)
    setError('')
    try {
      const attachments = []
      for (let i = 0; i < files.length; i += 1) {
        const file = files[i]
        setProgress({ name: file.name, ratio: 0, index: i + 1, total: files.length })
        // eslint-disable-next-line no-await-in-loop
        const meta = await uploadFile(file, (ratio) =>
          setProgress({ name: file.name, ratio, index: i + 1, total: files.length })
        )
        attachments.push(meta)
      }
      setProgress(null)

      const { error: insertError } = await supabase
        .from('posts')
        .insert({ title: title.trim(), body, attachments })
      if (insertError) throw insertError

      setTitle('')
      setBody('')
      setFiles([])
      if (inputRef.current) inputRef.current.value = ''
      onPosted()
    } catch (e) {
      setError(e.message || '등록에 실패했습니다. 잠시 뒤 다시 시도하세요.')
      setProgress(null)
    } finally {
      setBusy(false)
    }
  }

  const totalSize = files.reduce((sum, f) => sum + f.size, 0)

  return (
    <section className="composer">
      <div className="composer-head">
        <span className="composer-eyebrow">새 글</span>
        <button className="submit" type="button" onClick={submit} disabled={busy}>
          {busy ? '올리는 중…' : '등록하기'}
        </button>
      </div>

      <label className="field">
        <span className="field-label">제목</span>
        <input
          className="input"
          value={title}
          maxLength={200}
          placeholder="한 줄로 요약해 주세요"
          onChange={(e) => setTitle(e.target.value)}
        />
      </label>

      <label className="field">
        <span className="field-label">내용</span>
        <textarea
          className="textarea"
          value={body}
          rows={5}
          placeholder="자유롭게 쓰세요"
          onChange={(e) => setBody(e.target.value)}
        />
      </label>

      <div className="field">
        <span className="field-label">
          첨부파일 <em className="hint">파일 1개당 최대 {MAX_MB}MB · 개수 제한 없음</em>
        </span>
        <div
          className="dropzone"
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => {
            e.preventDefault()
            addFiles(e.dataTransfer.files)
          }}
        >
          <input
            ref={inputRef}
            id="file-input"
            className="file-input"
            type="file"
            multiple
            onChange={(e) => addFiles(e.target.files)}
          />
          <label className="file-button" htmlFor="file-input">
            파일 선택
          </label>
          <span className="dropzone-text">여기로 끌어다 놓아도 됩니다</span>
        </div>

        {files.length > 0 && (
          <ul className="file-list">
            {files.map((file, i) => (
              <li key={`${file.name}-${i}`} className="file-chip">
                <span className="file-name">{file.name}</span>
                <span className="file-size">{formatBytes(file.size)}</span>
                <button
                  type="button"
                  className="file-remove"
                  onClick={() => removeFile(i)}
                  aria-label={`${file.name} 빼기`}
                >
                  ×
                </button>
              </li>
            ))}
            <li className="file-total">합계 {formatBytes(totalSize)}</li>
          </ul>
        )}
      </div>

      {progress && (
        <div className="progress">
          <div className="progress-bar">
            <div className="progress-fill" style={{ width: `${Math.round(progress.ratio * 100)}%` }} />
          </div>
          <span className="progress-text">
            {progress.index}/{progress.total} · {progress.name} · {Math.round(progress.ratio * 100)}%
          </span>
        </div>
      )}

      {error && <p className="error">{error}</p>}
    </section>
  )
}

function Attachment({ file }) {
  const isImage = file.type?.startsWith('image/')
  return (
    <a className={`attachment${isImage ? ' is-image' : ''}`} href={file.url} target="_blank" rel="noreferrer">
      {isImage ? (
        <img src={file.url} alt={file.name} loading="lazy" />
      ) : (
        <span className="attachment-icon" aria-hidden="true">
          ↓
        </span>
      )}
      <span className="attachment-meta">
        <span className="attachment-name">{file.name}</span>
        <span className="attachment-size">{formatBytes(file.size)}</span>
      </span>
    </a>
  )
}

function Post({ post, onDeleted }) {
  const [open, setOpen] = useState(false)
  const date = new Date(post.created_at)
  const stamp = `${date.getMonth() + 1}월 ${date.getDate()}일 ${String(date.getHours()).padStart(2, '0')}:${String(
    date.getMinutes()
  ).padStart(2, '0')}`

  const remove = async () => {
    if (!window.confirm('이 글을 지웁니다. 되돌릴 수 없습니다.')) return
    const paths = (post.attachments || []).map((a) => a.path).filter(Boolean)
    if (paths.length) await supabase.storage.from(BUCKET).remove(paths)
    await supabase.from('posts').delete().eq('id', post.id)
    onDeleted(post.id)
  }

  const attachments = post.attachments || []

  return (
    <article className={`post${open ? ' is-open' : ''}`}>
      <button className="post-head" type="button" onClick={() => setOpen((v) => !v)}>
        <h2 className="post-title">{post.title}</h2>
        <span className="post-meta">
          {attachments.length > 0 && <span className="clip">첨부 {attachments.length}</span>}
          <time>{stamp}</time>
        </span>
      </button>

      {open && (
        <div className="post-body">
          {post.body && <p className="post-text">{post.body}</p>}
          {attachments.length > 0 && (
            <div className="attachments">
              {attachments.map((file) => (
                <Attachment key={file.path} file={file} />
              ))}
            </div>
          )}
          <button className="post-delete" type="button" onClick={remove}>
            글 지우기
          </button>
        </div>
      )}
    </article>
  )
}

export default function App() {
  const [posts, setPosts] = useState([])
  const [status, setStatus] = useState('loading')

  const load = useCallback(async () => {
    if (!IS_CONFIGURED) {
      setStatus('unconfigured')
      return
    }
    const { data, error } = await supabase
      .from('posts')
      .select('*')
      .order('created_at', { ascending: false })
    if (error) {
      setStatus('error')
      return
    }
    setPosts(data ?? [])
    setStatus('ready')
  }, [])

  useEffect(() => {
    load()
    if (!IS_CONFIGURED) return undefined
    const channel = supabase
      .channel('posts-live')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'posts' }, load)
      .subscribe()
    return () => {
      supabase.removeChannel(channel)
    }
  }, [load])

  return (
    <div className="page">
      <Banner />
      <main className="content">
        <Composer onPosted={load} />

        <section className="board">
          {status === 'loading' && <p className="board-note">글을 불러오는 중…</p>}
          {status === 'unconfigured' && (
            <p className="board-note">
              아직 Supabase에 연결되지 않았습니다. config.js 파일을 열어 Project URL과
              anon public 키를 넣어 주세요.
            </p>
          )}
          {status === 'error' && (
            <p className="board-note">
              데이터베이스에 연결하지 못했습니다. 주소와 키, 그리고 SQL 설정을 다시 확인하세요.
            </p>
          )}
          {status === 'ready' && posts.length === 0 && (
            <p className="board-note">아직 글이 없습니다. 첫 글을 올려 보세요.</p>
          )}
          {posts.map((post) => (
            <Post
              key={post.id}
              post={post}
              onDeleted={(id) => setPosts((prev) => prev.filter((p) => p.id !== id))}
            />
          ))}
        </section>
      </main>
      <footer className="foot">2학년 3반 · 자유 게시판</footer>
    </div>
  )
}
