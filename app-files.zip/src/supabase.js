import { createClient } from '@supabase/supabase-js'

export const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL
export const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY

/** 첨부파일 버킷 이름 (Supabase Storage에서 만든 이름과 같아야 한다) */
export const BUCKET = import.meta.env.VITE_SUPABASE_BUCKET || 'attachments'

/**
 * 파일 1개당 최대 용량(바이트).
 * Supabase 대시보드의 Storage Settings > Global file size limit 값과 맞춰 둔다.
 * Free 요금제 상한은 50MB, Pro부터는 최대 500GB까지 올릴 수 있다.
 */
export const MAX_FILE_SIZE =
  Number(import.meta.env.VITE_MAX_FILE_SIZE_MB || 50) * 1024 * 1024

export const IS_CONFIGURED = Boolean(
  SUPABASE_URL && SUPABASE_ANON_KEY && String(SUPABASE_URL).startsWith('http')
)

if (!IS_CONFIGURED) {
  console.error(
    'VITE_SUPABASE_URL 과 VITE_SUPABASE_ANON_KEY 가 빌드에 들어가지 않았습니다. ' +
      '.env 파일(로컬) 또는 저장소 Secrets(GitHub Actions)를 확인하세요.'
  )
}

export const supabase = createClient(
  SUPABASE_URL || 'https://placeholder.supabase.co',
  SUPABASE_ANON_KEY || 'placeholder'
)
